<?php
$title = "Home";
$content = '<img src="gros.jpg" class="imgLeft" />
<h3>GROCERIES</h3>
<p> G-MART
Grocery & Gourmet Foods Top offers on Grocery essentials, Canned & Jarred Food
Cereal & Muesli Coffee, Tea & Beverages ,Cooking & Baking Supplies
Dried Fruits, Nuts & Seeds , Hampers & Gourmet GiftsJams, Honey & Spreads
Pasta & Noodles,Ready To Eat & Cook,Rice, Flour & Pulses
Snack Foods,Sweets, Chocolate & Gum
</p>

<img src="fash.jpg" class="imgRight"/>
<h3>FASHION</h3>
<p>
At E-MART Fashion, we believe our customers can be smart and stylish. 
That’s exactly why we offer a vast, shoppable selection of women’s and mens clothing,
 shoes, jewelry, watches, handbags and more. Whether you’re in the market 
 for office-friendly blazers, maxi dresses and off the shoulder tops for your next vacation, 
 or everyday essentials, there’s bound to be something for your closet. Each season,
  you’ll find a carefully curated assortment of men’s clothing and accessories from emerging 
  and established brands like kate spade new york, Michael Kors, adidas,
   Alex and Ani, Calvin Klein, Cole Haan, and many more.
</p>

<img src="ece.jpg" class="imgLeft" />
<h3>ELECTRONICS</h3>
<p>
The Electronics Store
At E-MART India, you will be able to find a wide selection of electronics
from top brands. Shop for Mobile Phones, Tablets, Cameras, Televisions, Headphones,
Speakers, Laptops, Computers & Accessories, Wearables, Office Products, Data Storage, 
Gaming accessories, Musical Instruments and much more at the best prices on Amazon.in.


</p>';

include 'Template.php';
?>

