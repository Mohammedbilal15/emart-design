
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" />

  <title>Register Form</title>
</head>
<body>
<div class="form-wrapper">
 <form action="inspro.php" method="POST">
  <table>
   <tr>
 <td>PRODUCT type:</td>
 <td><input type="text" name="pro_type" required></td>
 </tr>
   <td>product id:</td>
    <td><input type="text" name="pro_id" required></td>
    </tr>
    <tr>
    <td> Product Name :</td>
    <td><input type="text" name="proname" required></td>
   </tr>
   <tr>
    <td>Availability:</td>
    <td><input type="" name="avail" required></td>
   </tr>
   <tr>
    <td>quantity:</td>
    <td><input type="text" name="quantity" required></td>
   </tr> 
   <center><td><input type="submit" value="Submit"></td></center>
   </tr>
  </table>
 </form>
 </div>
</body>
</html>