#include<stdio.h>
int main
{
    int n=9,i;
    for(i=0;i<n;i++)
    {
        print(i);
    }
}