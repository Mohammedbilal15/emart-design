<!DOCTYPE html>
<html>
<head>
<?php 
        $content = '<img src="Product.jpeg" class="imgLeft" />'
   
       
        ?>
<link rel="stylesheet" type="text/css" href="Stylesheet.css" />
</head>     

<body>
<div id="wrapper">
<div id="banner">             
            </div>

<nav id="navigation">
<ul id="nav">
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="ADDUSER.php">ADD USER</a></li>
                    <li><a href="viedid1.php">VIEW USER</a></li>
                 
                </ul>
                </nav>
                
                <div id="content_area">
                <?php echo $content; ?>
      
      <h3>WELCOME TO E-MART </h3>
      <h>
          One of India's biggest shopping mart.It offers large variety of products for its customer.It mainly aims at providing customer satisficattion with full value guarentee in all their products.
      </h>
     

            </div>
            <footer>
                <p>All rights reserved</p>
            </footer>
            </div> 

</body>
</html>