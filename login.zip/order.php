
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" />

  <title>Register Form</title>
</head>
<body>
<div class="form-wrapper">
 <form action="insord.php" method="POST">
  <table>
   <tr>
 <td>ORDER type:</td>
 <td><input type="text" name="ord_type" required></td>
 </tr>
 </div>
   <td>ORDER id:</td>
    <td><input type="text" name="ord_id" required></td>
    </tr>
    <tr>
    <td> ORDER Name :</td>
    <td><input type="text" name="ordname" required></td>
   </tr>
   <tr>
    <td>DATE AND TIME:</td>
    <td><input type="" name="ord_dat" required></td>
   </tr>
   <tr>
    <td>quantity:</td>
    <td><input type="text" name="quan" required></td>
   </tr> 
   <td><input type="submit" value="Submit"></td>
   </tr>
  </table>
 </form>
 
</body>
</html>